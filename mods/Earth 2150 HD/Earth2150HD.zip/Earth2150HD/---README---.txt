INTRODUCTION

Getting tired of the slow and unresponsive interface? Getting tired of low quality visuals? Wanna see something different with Reshade?

Low and behold:

Dgvoodoo2 is used to add antialiasing without the need of tinkering with driver settings.
60FPS fixes add much better control and weather effects look MUCH nicer. 
Reshade is used to add sharpening, color correction and overall a different picture from the base game. It's still somewhat customizable.

------

HOW TO INSTALL:


1- Run "Setup.exe" in your main game folder. (As a shortcut, right-click on game on Steam Library > Manage > Browse local files)

2- Select "display Direct3D HAL".

3- Choose 1680x1050x32 or 1400x1050x32 and click OK/yes both times. 1080p and similars result in a crash when opening the construction menu.

4- Extract all folders and files in the first link to your game installation folder. Use 7zip or WinRAR to open.

5- Make sure "dgVoodooCpl.exe" doesn't get deleted or moved by your ANTIVIRUS or WINDOWS DEFENDER. Add an exclusion manually or disable it temporarily and then do it. It's a false positive and the patch NEEDS it to work properly.

6- Once ingame, select any campaign and start it, go to menu > options > interface > type and select the desired 16:10 interface. Remember to enable terrain shadows.

7- While playing, press enter and type (just to make sure):

graphrate 60

8- Enjoy!

TROUBLESHOOTING:

If the DGVOODOO WATERMARK appears, you might have done something wrong. Recheck your ANTIVIRUS or WINDOWS DEFENDER and restore the affected dgvoodoocpl.exe files (absolutely necessary for the patch).

If this still doesn't work for you, then run dgvoodoocpl.exe and leave the settings like this:

Always compare your game to the screenshots here so this works correctly.

If the games crash at the start, look up how to enable Data Execution Prevention (DEP) on WINDOWS files and services only. The fastest way is "Windows key + Pause key" > Advanced system settings > Under "Performance" click settings > Data Execution Prevention tab > click "Turn on DEP for all Windows files and services only" > Restart.

If the executable files don't open, end them in Task Manager and open them again.

If the game still crashes at start, run the executable in WinXP SP3 Compatibility Mode. (Right click on .exe > Properties > Compatibilty > Tick "Run this program in compability mode for:" and select Windows XP (Service Pack 3).

If you want to disable Reshade, delete or rename "dxgi.dll" or "opengl32.dll".

If you have problems with the later games, extract the contents inside the Mixsets folder to your main directory.

If the game is too fast, press the * key to reset default speed.

If the cutscenes don't work. Install K-Lite Codec Pack Basic.

Also remember to disable Windows mouse acceleration. (also called "Enhance Pointer Precision"). Fastest way is Windows key > Search "mouse" > Mouse properties > Additional mouse options > Pointer options > Untick "Enhance Pointer Precision".

AND set global Vsync options to OFF in your graphics panel. Otherwise it causes problems with your mouse.

Comment below if any other problems appear.

------

THANKS to Holybrake for adding input in the making of this and his interfaces.
THANKS to Corosar for providing the original interfaces and tools.
THANKS to hz$$65 for feedback.

------