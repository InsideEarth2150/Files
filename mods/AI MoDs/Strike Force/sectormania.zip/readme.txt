(------------------------------------- SectorMania! -------------------------------------)
                          Gametype Modification by CABAListic
------------------------------------------------------------------------------------------

�BERSICHT
-----------
Bei 'SectorMania!' werden die normalen Ressourcen von 'Moon Project' durch spezielle 
Sektoren ersetzt, die die Spieler besetzen m�ssen, um Geld zu bekommen. Durch diesen
leichteren Mining-Ersatz k�nnen sich die Spieler mehr auf das Wesentliche konzentrieren,
wodurch das Spiel schneller und m�glicherweise auch taktischer wird.



GAME-SETUP
------------
In der Gamelobby gibt es neue Einstellungsoptionen f�r das Gameplay:

'CASH FOR SECTOR': Hiermit wird festgelegt, wieviel Credits ein Spieler bzw. sein Team f�r
einen eroberten Sektor erhalten. Entweder kann man den Betrag direkt festlegen oder vom 
Skript selbst ermitteln lassen ('Choose by map'). In diesem Fall ermittelt das Skript 
anhand der vorhandenen Sektoren auf der Map sowie der Anzahl an Mitspielern die Geldmenge.

'WIN CONDITION': Das Ziel des Spiels. In der ersten Einstellungsoption ('Destroy
structures') m�ssen die Spieler alle Geb�ude eines feindlichen Spielers zerst�ren, w�hrend
in der zweiten Einstellungsm�glichkeit ('Conquer all enemy sectors') s�mtliche Sektoren
der feindlichen Spieler / des feindlichen Teams erobert werden m�ssen, um zu gewinnen.

'RESEARCH TIME': Dauer f�r eine Forschung. Voreingestellt ist 2x Forschungsgeschwindigkeit.
Die Option 'automatic research' ist bislang nicht integriert...

'AVAILABLE RESEARCHES': Ausschalten von ungew�nschten Forschungen, Bomben und/oder MVW.

'TEAM GAME': Ist diese Option angeschaltet, so erhalten auch alle verb�ndeten Spieler
f�r einen eroberten Sektor Geld. Ist sie ausgeschaltet, so erh�lt nur der Besitzer des
Sektors Credits.

'DESTROY SECTOR WITH OWNER': Ist diese Option eingeschaltet, dann explodieren s�mtliche
Objekte innerhalb eines Sektors, wenn die den Sektor besetzende Unit zerst�rt wird.



GAMEPLAY
----------
Sowie das Spiel gestartet ist, werden auf der Karte automatisch kleine, 9x9 gro�e Felder
generiert, die die Sektoren verk�rpern. Ihr Mittelpunkt ist besonders gekennzeichnet,
auf dieses Feld muss der Spieler eine Landeinheit plazieren (dauerhaft, wohlgemerkt), um
einen Sektor zu "erobern" und Geld f�r ihn zu bekommen. Wird die Einheit von dort 
entfernt, sei es, weil der Spieler sie wegbewegt oder sie zerst�rt wird, dann ist der 
Sektor wieder frei, und der Spieler bekommt kein Geld mehr f�r ihn, bis er nicht eine 
neue Unit auf ihm plaziert hat.
Alles andere bleibt unver�ndert, nach wie vor muss der Spieler forschen und Einheiten
bauen. Einzig zu erw�hnen bliebe, dass die Einheitentransporter deaktiviert wurden, da
sie Balancingprobs mit diesem Mod verursacht haben.



KARTEN F�R SECTORMANIA
------------------------
Um 'SectorMania!' spielen zu k�nnen, muss die verwendete Karte den Mod auch unterst�tzen.
Um dies zu erreichen, m�ssen auf ihr im Editor so genannte Marker plaziert werden. Diese
finden sich unter "Objekte -> neutral -> Marker" und werden genau so plaziert wie die
Startpunkte auch. Jeder Marker repr�sentiert den Innenpunkt eines Sektors, der Mod 
generiert die Begrenzung des Sektors selbst. Zu beachten ist lediglich, dass maximal
100 Sektoren auf einer Map vorkommen k�nnen, aber das sollte auch ausreichen. Die Marker
m�ssen durchlaufend von 0 bis zum letzten plazierten Feld vorhanden sein, eine L�cke in 
der Reihe w�rde eines der Felder unbrauchbar machen!