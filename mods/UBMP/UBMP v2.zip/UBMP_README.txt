UBMP version 1 for Public Release!

Project: UBMP
*****************************************
by ribdeth 
(can be contacted at ribdeth@yahoo.com)

This is the 3nd version of UBMP and is the
1st for Public release.  It was preceded by
2 beta versions.  No longer for testing
purposes only. ;)  I would like to 
apologize to all of those who were
interested in beta-testing UBMP and were
denied, and then had to put up with a
longer than expected duration before the
public release.  Hopefully it was worth the
wait.  Any suggestions for improving this
MOD are highly appreciated.  This version will
become obsolete due to corrections &/or
updates and should be deleted after newer
version(s) are distributed.


Installation
_________________________________________
1. Download & Unzip the UBMP.zip
2. Copy the UBMP.wd and paste into
   the WDFiles folder of The Moon Project
   Directory.
   (copy=Ctrl+C or right click and select
   copy, paste=Ctrl+V or right click and
   select paste in the appropriate
   directory.)
3. Start up The Moon Project ;)


****Important**Note****
_________________________________________
Make sure you remove(or delete) the 
UBMP.wd from the WDfiles folder if playing
a multiplayer game.  Also remember to remove
the original BetaUBMP.wd or Beta2UBMP.wd
before adding the 2UBMP.wd to the wdfiles
folder.(if previous beta tester)



Notes about UBMP 
_________________________________________
1. The Alien Weapon was given a long
   Research Time.
2. The Alien Weapon was made visible in
   the Research and Construction Screens.
3. The Alien Craft now accomodates regular
   light weapons instead of aircraft
   weapons.
4. The Harvesters(I,II,&III) were given
   shortened research times and the
   Harvester I is a cheaper research.


Notes about Beta2UBMP 
_________________________________________
1. The Plasma Beam Projector has been
   added for the Fang.  The Alien Weapon
   has been added for the Alien Craft.
   The Alien Weapon model doesn't appear
   on the research screen, and this is
   being looked into.  Also, the Artillary
   model for the Fang is still too big and
   I hope to fix this as well.
2. All of the new items now work in
   TechWars without needing to be 
   researched.  This was fixed from the
   last version.  I haven't been able to
   test this in a multiplayer game, but it
   should run regularly.  
3. Beta2UMP is highly imbalanced and I'm
   looking into balancing issues before
   making the public distribution.  This
   is the biggest problem that I'm aware
   of.


Notes about BetaUBMP
_________________________________________
1. Grizzlies I, II, & III added for UCS.
   Research for Grizzly II is listed as
   Upg: Grizzly instead of Upg: Grizzly I.
2. Fang and UFO added for LC.  The UFO
   uses aircraft weapons even though it's
   a ground vehicle.  Fang is researchable
   as a superior chassis for the Plasma
   Artillery.  The Crion is slow and weak,
   and will probably be adjusted slightly
   in future versions(or the Fang).
3. The Truck, Tank, and Heavy Tank are
   added for ED, with the accompanying
   weapons.  The regular weapon for the
   Heavy Tank and Tank is Heavy Rockets,
   which must be researched.  After these
   are researched, they will be listed as
   105mm Cannon after being mounted to the
   chassis.  This is an error on
   Developer's part ;P  AAR will be
   researched along with Heavy Rockets.


Final Notes
_________________________________________
UBMP can be *rather easily* adjusted for
stats, research, etc., so any ideas
regarding this mod are appreciated.  Feel
free to email me regarding this mod(the
address is ribdeth@yahoo.com), or post
ideas at the Scripts, Mods, Maps, & Other
Projects section of the FoC Forum.  The
FoC forum can be found at our webpage @
http://foc.newst.org/ and select Forum.
