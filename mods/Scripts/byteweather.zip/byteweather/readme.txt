Des_byte.eco
WEATHER MOD BY GERMAN SCRIPTER -- BYTE
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
To Install
=======

Place the .eco file in the "Single" folder under "Gametypes" in the "Scripts" folder in the Earth 2150 directory.
This is usually located C:\Program Files\SSI\Earth 2150\Scripts\Gametypes\Single or C:\SSI\Earth 2150\Scripts\Gametypes\Single
If the necessary folders do not exist, than create them.

Run the game!

The weather script runs the chosen weather type across the map.


-Ice Man
http://www.earth-orbiter.com

=====================================================
VISIT OUR FORUM TO DISCUSS EARTH 2150 ISSUES, TACTICS, PROBLEMS AND MORE
HTTP://WWW.EARTH-ORBITER.COM/FORUM.HTML
