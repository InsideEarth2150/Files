Here it is !!!!!!
The two "advance" scripts will be in addition to the original script, defaulting to:
 - "retreat no ammo" and "hold position"
 - "retreat no ammo" and "hold area".
Added new button: "Attack Hold Pos." When "on" the units will not move when you manually attack, even if the target is not in range (the settings for this button will not affect the unit in "auto attack" mode).Now the scripts now will try to keep the units at max weapon range every time they attack.(even in "auto attack" mode).If the unit has more then one weapon, it will use the weapon range found under "equipment 1" in the F1 screen.Also the units will respond quicker after acquiring a target. 
There are some times when the units can't hold max range: 1)if there is something between your unit and target (the main gun don't have a clear shot), the unit will move around the obstacle or 2)if the target is moving in the direction of the attacking unit.
The script gives some advantage even in "Hold Position - auto attack" mode. (hope you guys can find it and use it to your "advantaged").
------------------------------------------------------------------------------------
BTW - when you create a "platoon" your units will use a different script, the "platoon" script. The sad part about this is that I have a mod "platoon" script (just as good as the "Adv Max Range" script(s)) but I can't find any way to make the units (in platoon state) to use it.I will keep trying!
------------------------------------------------------------------------------------
8/21/00 update

- same features with some improvements.
====================================================================================
====================================================================================

10/12/00  - New A.A.Mode script!

New button: "AA Mode" ON / OFF . When "On" the unit will not fire his rockets unless the target is airborne.( it will fire at ground targets, if it has more cannons which are not rockets).
 -"Patrol" and "Escort" states will turn the AA Mode "OFF" (if is ON), and it will be turn back "ON" at exit.
 - If your unit has only one cannon and you give the "Attack" command, the unit will fire even if AA Mode is ON.
 - Default is "ON" if the unit has "rockets" or "OFF" if no rockets are present.
------------------------------------------------------------------------------------
I try to test these scripts for every possible situation the unit may encounter, if I overlook something please let me know: 


                My email is -  earthrts@stny.rr.com

------------------------------------------------------------------


THE SCRIPTS NEED TO BE IN YOUR GAME DIRECTORY, UNDER "...\Earth 2150\scripts\units",
if this directory don't exists you need to create one.

Remember that every time you add or remove scripts you need to go to the "F1" screen and update all your units with the script of choice.

