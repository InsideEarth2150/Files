Welcome to MOOS!

===============
!!! WARNING !!!
===============
MOOS is still in beta status, so there's absolutely NO guarantee that it works the way it should!


you can report bugs to moos@e2160.de
NOTE: The graphical problem with the userlist is a known bug.
Workaround: select the channels tab and then switch back to the User tab.

=====================================================================================================
moos supports multiple profiles. So if you use moos for both KS and TMP or multiple Accounts and
you don't want to enter the login data each time you change the account to the following:

- Create a shortcut to the moos executable
- Edit the shortcut's properties
- add quotes to the path and add a profile name (eg. "C:\moos\moos-win32.exe" myKSprofile)

moos will now use a different config file if you start this shortcut.
To use multiple profiles, simply repeat these steps but use another profilename.

**********************************************************************************************

moos has now support for KnightShift Earthnet. 
As KnightShift uses Serials which get transmitted encrypted, login isn't 
as simple as it could be. You first have to record your Knightshift login. 
Perform following steps to do this:

- Click on Connection -> Get KS Profile.. 

- Start KnightShift

- Go to multiplayer -> earthnet

- Add a new server with any desired name. As adress use: localhost or 127.0.0.1

- Connect to this server

- You will get refused by the server immediately, but this is normal

- now quit KnightShift and go back to the KS Login window

- there should be a message which says that the login data got collected successfully. 
  If this is not the case, report this to moos@e2160.de

- click on the save button and choose a filename. Hint: use something simple like C:\Earthnet.ksl

- click on the close button

- click on Connection -> Login as..

- enter the Username of your Account and any password (password is not needed for KnightShift login)

- check the Save setting. You should enable Save in case you don't want to 
  perform these steps each time you use MOOS

- go to the server tab and enter server settings 
  (Server: netserver.earthnet.de Port: 17171 Servertype: KnightShift)

- got to the KnightShift tab and enter the location of your login file (eg. C:\EarthNet.ksl)

That's it!


