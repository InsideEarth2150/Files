==================================
 Inside Earth Operations presents
*** Earth 2150: TMP Extensions ***
        by GvardianDLVII
==================================
Wersja 1.0.6

InsideEarth - Community Discord Server: https://discord.gg/yxtzdUZ

1. Instalacja
a) instalacja pierwszy raz
   - wrzuć dsound.dll do folderu z grą (tam gdzie jest TheMoonProject.exe którym uruchamiasz grę). 
     Jeśli taki plik już tam jest, to prawdopodobnie masz już jakiś inny mod który wczytuje pliki .asi.
     W takiej sytuacji nie musisz nadpisywać pliku.
   - stwórz (jeśli jeszcze nie istnieje) folder "scripts" w folderze gry
   - wrzuć do tego folderu EarthTmpExtensions.1.0.6.asi i EarthTmpExtensions.ini
b) aktualizacja z poprzedniej wersji
   - Usuń istniejący plik EarthTmpExtensions.X.X.X.asi z folderu "scripts" w katalogu z grą
   - wrzuć plik EarthTmpExtensions.1.0.6.asi do folderu "scripts" w katalogu z grą
   - (opcjonalnie) nadpisz lub zmodyfikuj plik EarthTmpExtensions.ini file. Krok ten jest opcjonalny, bo
     w przypadku braku pliku ini (lub któregoś z wpisów w środku) mod korzysta z wartości domyślnych,
     które są takie same jak w załączonym pliku ini.

2. Funkcjonalności
- wsparcie dla rozdzielczości 16:9 (gra nie crashuje konstruktorze F1)
- znacząca poprawa FPS za sprawą optymalizacji w renderowaniu
- dostosowanie GUI do dużych rozdzielczości - mniejszy rozmiar panelu bocznego i mniejszy kompas
- prawie wszystko można skonfigurować
- w pełni client-side (można używaćw grach multiplayer bez konieczności posiadania moda przez serwer 
  lub przez innych graczy)
- poprawka paska tytułowego wyświetlającego się w trybie pełnoekranowym na Steamowej wersji w Windows 10

3. Podziękowania dla:
- Animal, za testowanie i zgłaszanie błędów
- InsideEARTH community

Changelog:
1.0.6:
   - poprawiono wyświetlanie efektów na jednostkach i budynkach, które czasami wyświetlały się "za obiektem"
