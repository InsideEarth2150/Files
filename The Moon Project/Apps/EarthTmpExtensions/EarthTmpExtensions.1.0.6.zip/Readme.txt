==================================
 Inside Earth Operations presents
*** Earth 2150: TMP Extensions ***
        by GvardianDLVII
==================================
Varsion 1.0.6

InsideEarth - Community Discord Server: https://discord.gg/yxtzdUZ

1. Installation
a) new install
   - place dsound.dll into your game directory (next to the .exe you use to run the game). If it
     already exists, then most likely you have some other .asi mod installed, and you do not need
     to override it.
   - create (if not exists) scripts directory in your game directory
   - put EarthTmpExtensions.1.0.6.asi and EarthTmpExtensions.ini into that scripts directory
b) upgrade from previous version
   - remove existing EarthTmpExtensions.X.X.X.asi from you game's scripts folder
   - place EarthTmpExtensions.1.0.6.asi from the package into you game's scripts folder
   - (optionally) override/merge your EarthTmpExtensions.ini file. This is optional, because if
     there is no ini game uses default values which are exactly the same as those provided in ini.

2. Features
- widescreen 16:9 support (no crash in F1 menu)
- significant FPS imrovement due to rendering optimizations
- large resolutions adjustments - smaller sidepanel and compass
- almost everything is configurable
- fully client-side (you can use it in MP games without the need of other players having it as well)
- titlebar fix (overlapping titlebar in Steam version on Windows 10)

3. Thanks to:
- Animal, for testing and bug reporting
- InsideEARTH community

Changelog:
1.0.6:
   - fixed unit/building effects rendering "behind" the object (ie. screamer effect, no power info etc)