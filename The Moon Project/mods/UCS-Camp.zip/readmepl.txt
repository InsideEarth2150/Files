Instalacja:
 
ucs-maps.zip rozpakuj do katalogu Levels TMP. Powinny po tym byc tam takie dane jak: !410.lnd,itp. 
Dla ucs-scripts.zip utworz folder i tam rozpakuj ten plik. U mnie np. wyglada to tak:
 
 ..\Topware\The Moon Project\Scripts\Campaigns\UCS\missions
 
 Zmieniony skrypt AI Platoon znajduje sie w:
 
 ..\Topware\The Moon Project\Scripts\Units\Ai
 
 U ciebie tez powinno wygladac to podobnie ;-)
 
Aby wszystko zdeinstalowac poprostu usun folder Scripts a w folderze Levels usun wszystkie pliki !4xx.lnd, !4xx.mis, !UCSBaseUCS*.* Usun te dane...

*************************************************************************************
Wskaz�wka: Dla trybu multiplayer w sieci zmien nazwe folederu Scripts lub go usun. W przeciwnym razie po uruchomieniu gry skrypty zostana wymienione pomiedzy komputerami. 
*************************************************************************************

Skrypty dzialaja tylko dla TMP (nie dzialaja z LS, Earth)

* Stopien trudnosci: Zostal ustawiony na "trudny" i przetestowany. Jego poziom miesci sie z poczatku gdzies pomiedzy oryginalnymi misjami a Lost Souls,a na koncu powyzej poziomu trudnosci w LS.

Wlasnosci: 

* poprzerabiane mapy, wynalazki, itd., w pierwszych misjach jest najmniej zmian, zwiekszaja sie one w alpha, beta, 
  gamma, ..., ostatnia misja 'Exekution' jest w wiekszosci calkiem nowa, *kto* dokonuje egzekucji nie jest jeszcze do konca   pewne ;-)
  Przynajmniej musialem porzucic moje cale dotychczasowe doswiadczenie w TMP  i myslec przy tym o Blackhawk'u...

  "jako doswiadczony gracz online potrzebuje obojetnie dla ilu max 1h.,
   kiedy armia byla stracona dla AI"

* Surowce: w koncu mozna kazda misje wtedy wygrac, kiedy AI zuzyje wszystkie surowce i jest plajta. W zadnym wypadku nie sa dotepne dodatkowe kredyty (poza pieniedzmi na starcie dla uzbrojenia budynk�w...) 

* optymalizacja skalowania KI (skumulowane ataki, z przerwami wystarczajacymi na regeneracje 
  , unikanie pojedynczych plutonow i tym podobnych)

* 99,95 % jednostek bojowych zostaje rzeczywiscie wyprodukowanych. Kazda zniszczona fabryka pojazdow bojowych jest takze malym krokiem do zwyciestwa...

* + duzo wiecej, np. wydana wojna podziemna, nowa modyfikacja 
  Grizzly (nie tam Banner+Banner Grizzly ;-), itd. ..

Tipsy:

* Jakosc atakow KI uzalezniona jest od tego, w ktorym miejscu gracz postawi pierwsza elektrownie.Probowalem  uzbroic mozliwie trudne dla AI miejsca  (wysokie gory, itd.) , gwarantowac naturalnie nie moge za nic ;-)

* UCS Florida: W koncu podobnie jak w oryginalnych misjach wszystkie dodatkowo uzyskane surowce nie sa przenoszone do nastepnych misji (50000 wystarcza) ... 

* Strefa ladowania: Ulepszone zachowanie obronne AI 

* Mailman: niezmieniony

* Alpha: dla misji Alpha koniecznie ustaw poziom trudnosci na'ciezki' w przeciwnym razie
  nie zauwazysz roznicy. Na poczatku rozbuduj sie w strategicznym punkcie, jednostki z  wraz jednostka specjalna szybko przenies w nowsze miejsce. Kiedy wszystkie jednostki beda uzbrojone w oslony typu 600, najgorsze przetrwales. Zachowanie AI odpowiada mniej wiecej trybowi 'skirmish'. 

* Pacificum: niezmieniony

* Beta: takze tutaj trzeba od poczatku prawidlowo planowac do przodu, w przeciwnym razie pojazdy Grizzlies 
  uciekna. Ulepszone defensywne i ofensywne zachowanie AI.

* Death Canyon: teraz wyraznie trudniejszy

* Gamma: Podczas tej misji zostaja wlaczone niektore wynalazki. Niezbedna jest dobrze umocniona baza, Ki atakuje naprawde mocno.

* Hollow Man: niezmieniony

* Delta: Konieczna duza flota powietrzna. Wspolpraca pomiedzy Dragonami SR a B musi dzialac.. Jest korzystne jezeli wszystkie Dragony z poprzednich misji zebraly ok. 4 punktow doswiadczenia, zatem srednio zyskuja 1050 HP.

* Exekution: Niezbedna bardzo dobrze rozbudowana baza, przede wszsytkim z duza iloscia broni przeciwlotniczej. Pierwszy cel to zajecie pierwszego wejscia do tunelu oraz zniszczenie wejsc po stronie LC...


               zycze dobrej zabawy

               Cayenne
