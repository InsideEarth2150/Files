Danke f�r das herunterladen des Screensaver mappacks. Zur Installation solltest du Datenkabel, Bloototh oder Infrarot benutzen. N�heres bitte mi Handbuch zum ger�t nachlesen.
Ein Programm zum �berspielen brauchst du nat�rlich auch. ACHTUNG! jeder Handyhersteller benutzt eigene Programme, n�her bitte auf der Homepage des Herstellers nachlesen.

19.3.2004 Martin"[CEV]Madde"Greca

Hey! das hat lange gedauert die screens zu animieren, also seit bitte nicht zu streng ;)

