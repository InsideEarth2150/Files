==============
   moos 2.1
==============

moos 2.1 has been modified by surrim. Original work by mensi and CABAListic.

moos is GPL'ed software, the source code is available through SVN (details on www.insideearth.de)