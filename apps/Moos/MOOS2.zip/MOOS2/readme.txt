=====================
 moos2 Public Beta 2
=====================

Installation:

- Zip in beliebigen Ordner entpacken
- moos2.exe starten


Tipps:

- Control+Enter fl�stert zum ausgew�hlten User
- Der Farbcode wird automatisch gespeichert (also einfach das erste Mal "<meinfarbcode>Text" schreiben, danach nur noch "Text")
- Den Farbcode kann man mittels <*>meintext wieder resetten


Bugs und Features:

Im InsideEarth Operations Forum melden
( Thread: http://www.insideearth.de/showthread.php?p=33258 )