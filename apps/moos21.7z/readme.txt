==============
   moos 2.1
==============

moos 2.1 has been modified by surrim. Original work by mensi and CABAListic.

Changes for 2.1.0.2064
- fixed problem with special chars, disabled multi byte strings
- restoring the window size should work now

Changes for 2.1.0.3062
- polish translation fixed (thanks to advance)
- end of line is now CR LF in translation files so you can edit them with notepad

Changes for 2.1.0.3061
- Fixed bug with restoring invalid window positions
- welcome message is now replacing all "<*>" with white color code
- no check for "EarthNet Beta Server"
- fixed whois dialog
- generating login message without third invalid unsigned int (bugfix)
- edidted sizers and spaces
- text background color fixed
- fixed default path for language files

Changes for 2.1.0.3055
- Rebuild with latest compiler and libs (GCC 4.5.0, wxWidgets 2.9.1, zlib 1.2.5)
- Fixed bug with restoring window position

Changes for 2.1.0.3053
- Position will be restored
- No channels (e.g. #MoonNet) for autocomplete

Changes for 2.1.0.3052
- Some fixes in polish.ini made by Winter

Changes for 2.1.0.3051
- Some fixes for Linux
- EXE is compressed with UPX
- New Readme Link
- Some fixes in hungarian.ini made by Tas
