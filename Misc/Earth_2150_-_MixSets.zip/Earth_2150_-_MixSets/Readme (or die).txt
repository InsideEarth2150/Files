  __  __ _      __  __           _     
 |  \/  (_)    |  \/  |         | | 2019
 | \  / |___  _| \  / | ___   __| |___ 
 | |\/| | \ \/ / |\/| |/ _ \ / _` / __|
 | |  | | |>  <| |  | | (_) | (_| \__ \
 |_|  |_|_/_/\_\_|  |_|\___/ \__,_|___/
                                       

=======   MixMods.com.br   ======= - Best visualization with monospaced fonts, like "Consolas".


------- Instructions:

Extract everything to your game folder.

[Earth 2150 - The Moon Project]
│   dsound.dll
│   ijl10.dll
│   Setup.exe
│   TheMoonProject.exe
├───Levels
├───Music
├───Players
├───Scripts
│       global.ini
│       MixSets.asi
│       MixSets.ini
├───Video
└───WDFiles


Compatible with any executable of Lost Souls or The Moon Project.
"dsound.dll" is the Ultimate ASI Loader: https://www.mixmods.com.br/2018/11/ultimate-asi-loader.html


Open the "MixSets.ini" file to configure to your liking.
 


Version: v1.1
--------------------

Author: Junior_Djjr


====   MixMods.com.br                ====
====   fb.com/FamiliaMixMods         ====
====   youtube.com/JuniorDjjrMixMods ====

