=======   Autoexec.con   ======= 

------- Installation

To install autoexec.con, simple place the file in the root of the game instalation;

Example:
[Earth 2150 - The Moon Project]
│   autoexec.con
│   ijl10.dll
│   Setup.exe
│   TheMoonProject.exe
├───Levels
├───Music
├───Players
├───Scripts
├───Video
└───WDFiles

------- File Modification

To modify the variables within the file, open with notepad;

------- Variables:

graphrate 60
graph.zoom.max=150,
graph.zoom.min 1
graph.limited.view=0,
graph.viewangle.min=0
graph.viewangle.max=5
graph.cursor.size=40
graph.Limited.View 0
display.show 0
console.help





